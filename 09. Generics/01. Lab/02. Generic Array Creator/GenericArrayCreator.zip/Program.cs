﻿using GenericArrayCreator;

Console.WriteLine(string.Join(",", ArrayCreator.Create(50, "Fifty")));